package com.mindtree.TravelManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TravelManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
