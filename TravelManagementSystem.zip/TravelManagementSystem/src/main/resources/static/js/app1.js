function call1(){
fetch('viewpackage',{
	method:'GET',
	headers:{
		'Content-Type':'application/json'
	}
}).then((response)=>{
	response.json().then((x)=>{
	const table=document.getElementById('table1');
	let tags="";
	let packageNames="";
	console.log(x);
	x.forEach((i)=>{console.log(document.getElementById('season').value))
	if(i.season==(document.getElementById('season').value))
		{
		packageNames+='<option value="'+i.package_name+'">'+i.package_name+'</option>';
		tags+='<tr>'+'<td>'+i.packageId+'</td>'+
		'<td>'+i.packageName+'</td>'+
		'<td>'+i.food+'</td>'+
		'<td>'+i.packageCost+'</td>'+
		'<td>'+i.packageDurationInDay+'</td>'+
		'<td>'+i.packageDurationInNight+'</td>'+
		'<td>'+i.season+'</td>'+'</tr>';
		}
		});
	document.getElementById('season').innerHTML=packageNames;
	document.getElementById('loop').innerHTML=tags;
	document.getElementById('packages').innerHTML="";
	});	
	
}).catch((err)=>{
});
}