package com.mindtree.TravelManagementSystem.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "TRAVELPACKAGE")
public class TravelPackage {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int packageId;

	private String packageName;

	private int packageCost;

	private String packageDurationInDay;

	private String packageDurationInNight;

	private String food;

	private String season;

	@OneToMany(mappedBy = "travelpackage", cascade = CascadeType.ALL)
	private List<Customer> customers;

	public TravelPackage() {
		super();
	}

	public TravelPackage(int packageId, String packageName, int packageCost, String packageDurationInDay,
			String packageDurationInNight, String food, String season, List<Customer> customers) {
		super();
		this.packageId = packageId;
		this.packageName = packageName;
		this.packageCost = packageCost;
		this.packageDurationInDay = packageDurationInDay;
		this.packageDurationInNight = packageDurationInNight;
		this.food = food;
		this.season = season;
		this.customers = customers;
	}

	public int getPackageId() {
		return packageId;
	}

	public void setPackageId(int packageId) {
		this.packageId = packageId;
	}

	public String getPackageName() {
		return packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	public int getPackageCost() {
		return packageCost;
	}

	public void setPackageCost(int packageCost) {
		this.packageCost = packageCost;
	}

	public String getPackageDurationInDay() {
		return packageDurationInDay;
	}

	public void setPackageDurationInDay(String packageDurationInDay) {
		this.packageDurationInDay = packageDurationInDay;
	}

	public String getPackageDurationInNight() {
		return packageDurationInNight;
	}

	public void setPackageDurationInNight(String packageDurationInNight) {
		this.packageDurationInNight = packageDurationInNight;
	}

	public String getFood() {
		return food;
	}

	public void setFood(String food) {
		this.food = food;
	}

	public String getSeason() {
		return season;
	}

	public void setSeason(String season) {
		this.season = season;
	}

	public List<Customer> getCustomers() {
		return customers;
	}

	public void setCustomers(List<Customer> customers) {
		this.customers = customers;
	}

	@Override
	public String toString() {
		return "TravelPackage [packageId=" + packageId + ", packageName=" + packageName + ", packageCost=" + packageCost
				+ ", packageDurationInDay=" + packageDurationInDay + ", packageDurationInNight="
				+ packageDurationInNight + ", food=" + food + ", season=" + season + ", customers=" + customers + "]";
	}

}
