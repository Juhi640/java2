package com.mindtree.TravelManagementSystem.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mindtree.TravelManagementSystem.dto.CustomerDto;
import com.mindtree.TravelManagementSystem.dto.TravelPackageDto;
import com.mindtree.TravelManagementSystem.entity.TravelPackage;
import com.mindtree.TravelManagementSystem.exception.ServiceException.TravelPackageCustomerServiceException;
import com.mindtree.TravelManagementSystem.service.CustomerTravelPackageService;

@Controller
public class AppController {

	@Autowired
	CustomerTravelPackageService customertravelpackageservice;

	@RequestMapping("/")
	public String login() {
		return "login";
	}

	@RequestMapping("/add")
	public String travelpackage() {
		return "addform";
	}

	@PostMapping(value = "/formadd")
	public String AddForm(TravelPackageDto travelpackagedto) {
		customertravelpackageservice.addPackageToDB(travelpackagedto);
		return "addform";
	}

	@GetMapping("/display")
	public String GetAllPackages(Model model) {
		List<TravelPackageDto> travelpackagesdto = new ArrayList<>();
		travelpackagesdto = customertravelpackageservice.getAllPackages();
		model.addAttribute("travelpackagesdto", travelpackagesdto);
		return "display";
	}

	@GetMapping("/viewpackage/{packageId}")
	public String GetPackage(@PathVariable int packageId, Model model) {
		TravelPackageDto travelpackagedto = customertravelpackageservice.getPackageById(packageId);
		model.addAttribute("travelpackagedto", travelpackagedto);
		return "update";
	}

	@PostMapping("/updatetable")
	public String updateTravelPackage(TravelPackage travelpackage) {
		customertravelpackageservice.updatePackageInDB(travelpackage);
		return "updatename";
	}
	
	@RequestMapping("/customerbooking")
	public String customer() {
		return "searchpage";
	}
	
	@RequestMapping("/viewtable")
	public String GetAllCustomers(@RequestParam String season, Model model) throws TravelPackageCustomerServiceException {
		List<TravelPackageDto> travelpackagesdto = new ArrayList<>();
		travelpackagesdto=customertravelpackageservice.getPackagesBySeason(season);
		model.addAttribute("travelpackagesdto",travelpackagesdto );
		return "searchpage";
	}
	
	@RequestMapping("/customerform/{packageId}")
	public String customeradd() {
		return "customerform";
	}
	
	@PostMapping("/addcustomer")
	public String addCustomer(CustomerDto customerdto,@RequestParam int packageId) {
		customertravelpackageservice.addCustomerToDB(customerdto, packageId);
		return "customerform";	
	}
	
	@RequestMapping("/booking")
	public String booked() {
	return"confirmbooking";
	}
	
}