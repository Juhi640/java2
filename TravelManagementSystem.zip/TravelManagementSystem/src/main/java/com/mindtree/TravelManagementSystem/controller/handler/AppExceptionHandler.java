package com.mindtree.TravelManagementSystem.controller.handler;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.mindtree.TravelManagementSystem.controller.AppController;
import com.mindtree.TravelManagementSystem.exception.ServiceException.seasonNotFoundException;

@ControllerAdvice(assignableTypes = {AppController.class})
public class AppExceptionHandler {
	
	@ExceptionHandler(seasonNotFoundException.class)
	private String emailNotFoundExceptionHandler(seasonNotFoundException e, Model model){
		model.addAttribute("error", e.getMessage());
		return "error";
	
		
	}

}
