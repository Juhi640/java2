package com.mindtree.TravelManagementSystem.repository;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.stereotype.Repository;

import com.mindtree.TravelManagementSystem.entity.TravelPackage;

@Repository
public interface TravelPackageRepository extends JpaRepositoryImplementation<TravelPackage, Integer>{

		

}
