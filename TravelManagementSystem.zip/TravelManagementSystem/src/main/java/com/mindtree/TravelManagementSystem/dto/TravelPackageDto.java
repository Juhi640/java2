package com.mindtree.TravelManagementSystem.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class TravelPackageDto {

	private int packageId;

	private String packageName;

	private int packageCost;

	private String packageDurationInDay;

	private String packageDurationInNight;

	private String food;

	private String season;

	@JsonIgnoreProperties("travelpackagedto")
	private List<CustomerDto> customersdto;

	public TravelPackageDto() {
		super();
	}

	public TravelPackageDto(int packageId, String packageName, int packageCost, String packageDurationInDay,
			String packageDurationInNight, String food, String season, List<CustomerDto> customersdto) {
		super();
		this.packageId = packageId;
		this.packageName = packageName;
		this.packageCost = packageCost;
		this.packageDurationInDay = packageDurationInDay;
		this.packageDurationInNight = packageDurationInNight;
		this.food = food;
		this.season = season;
		this.customersdto = customersdto;
	}

	public int getPackageId() {
		return packageId;
	}

	public void setPackageId(int packageId) {
		this.packageId = packageId;
	}

	public String getPackageName() {
		return packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	public int getPackageCost() {
		return packageCost;
	}

	public void setPackageCost(int packageCost) {
		this.packageCost = packageCost;
	}

	public String getPackageDurationInDay() {
		return packageDurationInDay;
	}

	public void setPackageDurationInDay(String packageDurationInDay) {
		this.packageDurationInDay = packageDurationInDay;
	}

	public String getPackageDurationInNight() {
		return packageDurationInNight;
	}

	public void setPackageDurationInNight(String packageDurationInNight) {
		this.packageDurationInNight = packageDurationInNight;
	}

	public String getFood() {
		return food;
	}

	public void setFood(String food) {
		this.food = food;
	}

	public String getSeason() {
		return season;
	}

	public void setSeason(String season) {
		this.season = season;
	}

	public List<CustomerDto> getCustomersdto() {
		return customersdto;
	}

	public void setCustomersdto(List<CustomerDto> customersdto) {
		this.customersdto = customersdto;
	}

	@Override
	public String toString() {
		return "TravelPackageDto [packageId=" + packageId + ", packageName=" + packageName + ", packageCost="
				+ packageCost + ", packageDurationInDay=" + packageDurationInDay + ", packageDurationInNight="
				+ packageDurationInNight + ", food=" + food + ", season=" + season + ", customersdto=" + customersdto
				+ "]";
	}

}
