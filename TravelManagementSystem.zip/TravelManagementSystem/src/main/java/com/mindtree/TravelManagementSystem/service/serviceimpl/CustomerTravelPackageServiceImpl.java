package com.mindtree.TravelManagementSystem.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.TravelManagementSystem.dto.CustomerDto;
import com.mindtree.TravelManagementSystem.dto.TravelPackageDto;
import com.mindtree.TravelManagementSystem.entity.Customer;
import com.mindtree.TravelManagementSystem.entity.TravelPackage;
import com.mindtree.TravelManagementSystem.exception.ServiceException.TravelPackageCustomerServiceException;
import com.mindtree.TravelManagementSystem.exception.ServiceException.seasonNotFoundException;
import com.mindtree.TravelManagementSystem.repository.CustomerRepository;
import com.mindtree.TravelManagementSystem.repository.TravelPackageRepository;
import com.mindtree.TravelManagementSystem.service.CustomerTravelPackageService;

@Service
public class CustomerTravelPackageServiceImpl implements CustomerTravelPackageService {

	@Autowired
	CustomerRepository customerrepository;

	@Autowired
	TravelPackageRepository travelpackagerepository;

	@Override
	public TravelPackageDto addPackageToDB(TravelPackageDto travelpackagedto) {
		TravelPackage travelpackage = new TravelPackage();
		travelpackage.setPackageId(travelpackagedto.getPackageId());
		travelpackage.setPackageName(travelpackagedto.getPackageName());
		travelpackage.setFood(travelpackagedto.getFood());
		travelpackage.setPackageDurationInDay(travelpackagedto.getPackageDurationInDay());
		travelpackage.setPackageDurationInNight(travelpackagedto.getPackageDurationInNight());
		travelpackage.setPackageCost(travelpackagedto.getPackageCost());
		travelpackage.setSeason(travelpackagedto.getSeason());
		travelpackagerepository.save(travelpackage);
		return travelpackagedto;

	}

	@Override
	public List<TravelPackageDto> getAllPackages() {
		List<TravelPackageDto> travelpackagesdto = new ArrayList<>();
		List<TravelPackage> travelpackages = travelpackagerepository.findAll();
		for (TravelPackage travelpackage : travelpackages) {
			TravelPackageDto travelpackagedto = new TravelPackageDto();
			travelpackagedto.setPackageId(travelpackage.getPackageId());
			travelpackagedto.setPackageName(travelpackage.getPackageName());
			travelpackagedto.setFood(travelpackage.getFood());
			travelpackagedto.setPackageDurationInDay(travelpackage.getPackageDurationInDay());
			travelpackagedto.setPackageDurationInNight(travelpackage.getPackageDurationInNight());
			travelpackagedto.setPackageCost(travelpackage.getPackageCost());
			travelpackagedto.setSeason(travelpackage.getSeason());
			travelpackagesdto.add(travelpackagedto);
		}
		return travelpackagesdto;
	}

	@Override
	public TravelPackageDto getPackageById(int packageId) {
		Optional<TravelPackage> travelpackage = travelpackagerepository.findById(packageId);
		TravelPackage t = travelpackage.get();
		TravelPackageDto travelpackagedto = new TravelPackageDto();
		travelpackagedto.setPackageId(t.getPackageId());
		travelpackagedto.setPackageName(t.getPackageName());
		travelpackagedto.setFood(t.getFood());
		travelpackagedto.setPackageDurationInDay(t.getPackageDurationInDay());
		travelpackagedto.setPackageDurationInNight(t.getPackageDurationInNight());
		travelpackagedto.setPackageCost(t.getPackageCost());
		travelpackagedto.setSeason(t.getSeason());
		return travelpackagedto;

	}

	@Override
	public void updatePackageInDB(TravelPackage travelpackage) {

		travelpackagerepository.saveAndFlush(travelpackage);
	}
	
	
	  @Override
	  public CustomerDto addCustomerToDB(CustomerDto customerdto,int packageId) {
		  Optional<TravelPackage> travelpackage = travelpackagerepository.findById(packageId);
			TravelPackage t = travelpackage.get();
			Customer customer=new Customer();
			customer.setCustomerId(customerdto.getCustomerId());
			customer.setCustomerName(customerdto.getCustomerName());
			customer.setEmailId(customerdto.getEmailId());
			customer.setMobileNo(customerdto.getMobileNo());
			customer.setTravelpackage(t);
			customerrepository.save(customer);
			return customerdto;
	  
	  }
	 
	
	@Override
	public List<TravelPackageDto> getPackagesBySeason(String season) throws TravelPackageCustomerServiceException{
		int found=0;
		List<TravelPackage> travelpackages=travelpackagerepository.findAll();
		List<TravelPackageDto> travelpackagesdto = new ArrayList<>();
		for(TravelPackage travelpackage:travelpackages) {
			if(travelpackage.getSeason().equalsIgnoreCase(season)) {
				found=1;
				TravelPackageDto travelpackagedto=new TravelPackageDto();
				 travelpackagedto.setPackageId(travelpackage.getPackageId());
				 travelpackagedto.setPackageName(travelpackage.getPackageName());
				 travelpackagedto.setFood(travelpackage.getFood());
				 travelpackagedto.setSeason(travelpackage.getSeason());
				 travelpackagedto.setPackageDurationInDay(travelpackage.getPackageDurationInDay());
				 travelpackagedto.setPackageDurationInNight(travelpackage.getPackageDurationInNight());
				 travelpackagedto.setPackageCost(travelpackage.getPackageCost());
				 travelpackagesdto.add(travelpackagedto);
			}
		}
		try {
			if(found==0) {
				throw new seasonNotFoundException("season not present");
			}
		}
		catch(seasonNotFoundException e) {
			throw new TravelPackageCustomerServiceException(e);
		}
		
		return travelpackagesdto;
		
		
		
	}
}
