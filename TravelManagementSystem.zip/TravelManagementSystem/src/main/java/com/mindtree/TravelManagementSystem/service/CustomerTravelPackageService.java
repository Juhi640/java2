package com.mindtree.TravelManagementSystem.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.TravelManagementSystem.dto.CustomerDto;
import com.mindtree.TravelManagementSystem.dto.TravelPackageDto;
import com.mindtree.TravelManagementSystem.entity.TravelPackage;
import com.mindtree.TravelManagementSystem.exception.ServiceException.TravelPackageCustomerServiceException;

@Service
public interface CustomerTravelPackageService {

	TravelPackageDto addPackageToDB(TravelPackageDto travelpackagedto);

	List<TravelPackageDto> getAllPackages();

	TravelPackageDto getPackageById(int packageId);

	void updatePackageInDB(TravelPackage travelpackage);

	List<TravelPackageDto> getPackagesBySeason(String season) throws TravelPackageCustomerServiceException;

	CustomerDto addCustomerToDB(CustomerDto customerdto, int packageId);

}
